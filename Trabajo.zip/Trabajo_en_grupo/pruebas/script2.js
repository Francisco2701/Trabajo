document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('mainMenuTrigger').addEventListener('click', function() {
      const mainMenu = document.getElementById('mainMenu');
      mainMenu.classList.toggle('hidden');
  });
});
