<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ficha de Producto</title>
  <link rel="stylesheet" href="styles11.css">
</head>

<body>
  <header>
    <h1 class="logo">Nombre de la Tienda</h1>

    <!-- Opciones de navegación u otros elementos del encabezado -->
    <!-- ... -->

    <div class="nav-items">
      <!-- Barra de búsqueda -->
      <form class="search-form">
        <input type="text" placeholder="Buscar...">
        <button type="submit">Buscar</button>
      </form>

      <!-- Icono de usuario o enlace de registro -->
      <a href="register.php" class="user-icon">
        <i class="fas fa-user"></i> Iniciar Sesión
      </a>
    </div>
  </header>

  <!-- Contenedor de la ficha del producto -->
  <div class="product-card">
    <img src="url_de_la_imagen" alt="Imagen del Producto">
    <h1>Nombre del Producto</h1>
    <p>Descripción breve del producto.</p>
    <p>Precio: $XX.XX</p>
    <button>Añadir al carrito</button>
  </div>

  <footer>
    <p>Nombre de la Tienda &copy; <?php echo date("Y"); ?></p>
  </footer>
</body>

</html>
