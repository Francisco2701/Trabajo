<?php
$servername = "127.0.0.1";
$username = "admin";
$password = "admin1234";
$dbname = "productos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username']; 
    $password = $_POST['password']; 

    echo "Username: " . $username . "<br>";
    echo "Password: " . $password . "<br>";

    $sql = "SELECT * FROM usuarios WHERE username = ?"; 
    $stmt = $conn->prepare($sql); 
    $stmt->bind_param("s", $username); 
    $stmt->execute(); 
    $result = $stmt->get_result(); 

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        echo "Password Hash: " . $row['password'] . "<br>";

        if (password_verify($password, $row['password'])) {
        } else {
            echo "Credenciales incorrectas"; 
            header("Location: principal.php");
            exit();
        }
    } else {
        echo "Usuario no encontrado"; 
    }

    $stmt->close(); 
}

$conn->close(); 
?>
