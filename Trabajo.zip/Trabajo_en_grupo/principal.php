<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tienda de Deportes</title>
  <link rel="stylesheet" href="styles/styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    integrity="sha512-..." crossorigin="anonymous" />
</head>

<body>
<div class="container">
<header class="header-container">
        <div class="flex-container">
        <div class="laschapas">
  <div>
    <button id="toggleMenu">
      <img src="img/laschapas.png" alt="LasChapas Logo">
    </button>
  </div>
  <h1 class="logo">LasChapas</h1>
</div>
        

            <form class="search-form">
                <input type="text" placeholder="Buscar...">
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>  
<div>
<a href="register.php" class="user-icon">
             <i class="fas fa-user"></i>
            </a>

            <a href="login.php" class="login-icon">
             <i class="fas fa-key"></i>
            </a>
</div>
            
        </div>
        

        <div class="nav-items">
            <nav id="mainMenu" class="hidden">
                <ul>
                    <li><a href="#">Tienda</a></li>
                    <li><a href="#">Ubicacion</a></li>
                </ul>
            </nav>
        </div>
    </header>

  <div class="store-new">
    <h2>Club De Futbol Las Chapas</h2>
    <p>
        El Club de Fútbol Las Chapas fue fundado en 2000 en Málaga. Desde sus inicios,
        ha sido un pilar fundamental en la comunidad futbolística local. El equipo ha experimentado una trayectoria llena de
        éxitos y desafíos, labrando su camino hacia la excelencia deportiva.
      </p>
      <p>
        A lo largo de los años, Las Chapas ha participado en diversas competiciones, conquistando numerosos títulos
        y trofeos. Sus logros han sido resultado del esfuerzo, dedicación y pasión de jugadores, entrenadores y aficionados
        que han formado parte de esta gran familia futbolística.
      </p>
      <p>
        La historia de Las Chapas está marcada por momentos memorables, rivalidades emocionantes y un legado de
        excelencia deportiva. Su compromiso con el fútbol de calidad y el desarrollo de jóvenes talentos ha sido un pilar
        fundamental en su filosofía.
      </p>  </div>

  <div class="product-carousel">
    <button class="prev-button">&lt;</button>
    <div class="products">
      <div class="product-group">
        <div class="product">
        <a href="productos/balon1.php">
        <img src="img/imagen1.jfif" alt="Producto 1">
        <h2>Producto 1</h2>
        </a>
        <p>Descripción del producto 1. Precio: $XX</p>
        <button>Agregar al carrito</button>
        </a>
        </div>

        <div class="product">
          <img src="img/imagen2.jfif" alt="Producto 2">
          <h2>Producto 2</h2>
          <p>Descripción del producto 2. Precio: $XX</p>
          <button>Agregar al carrito</button>
        </div>

        <div class="product">
          <img src="img/imagen3.jfif" alt="Producto 3">
          <h2>Producto 3</h2>
          <p>Descripción del producto 3. Precio: $XX</p>
          <button>Agregar al carrito</button>
        </div>

       
      </div>
      <div class="product-group hidden">
        <div class="product">
          <img src="img/imagen5.jfif" alt="Producto 5">
          <h2>Producto 5</h2>
          <p>Descripción del producto 5. Precio: $XX</p>
          <button>Agregar al carrito</button>
        </div>

        <div class="product">
          <img src="img/imagen6.jfif" alt="Producto 6">
          <h2>Producto 6</h2>
          <p>Descripción del producto 6. Precio: $XX</p>
          <button>Agregar al carrito</button>
        </div>

        <div class="product">
          <img src="img/imagen7.jfif" alt="Producto 7">
          <h2>Producto 7</h2>
          <p>Descripción del producto 7. Precio: $XX</p>
          <button>Agregar al carrito</button>
        </div>

        
      </div>
      <button class="next-button">&gt;</button>
    </div>
  </div>
  <div class="store-description">
  <p>
        El Club de Fútbol Las Chapas ha sido forjado por el esfuerzo y dedicación de personas clave que han
        contribuido significativamente a su desarrollo y éxito. Francisco Gabriel Poiana Lazar, figura fundamental en el
        equipo, ha desempeñado un papel crucial en la realización de los logros y la dirección del equipo hacia nuevos
        horizontes.
      </p>
      <p>
        Como miembro clave, Francisco Gabriel Poiana Lazar ha aportado su visión y pasión al club, influenciando en gran
        medida el camino que ha seguido el equipo. Su compromiso con el desarrollo deportivo y la excelencia ha sido una
        inspiración para todos los que forman parte de esta gran familia futbolística.
      </p>
</div>
<div class="logro">
    <div class="contenido">
        <h3>Campeones de la Champions</h3>
        <p>
            La participación en la prestigiosa Liga de Campeones de la UEFA ha sido una experiencia inolvidable para nuestro equipo. En 2019, nuestro equipo demostró su destreza, perseverancia y espíritu de equipo al coronarse como campeones en una emocionante final. La dedicación y el esfuerzo de cada jugador, entrenador y miembro del personal técnico fueron fundamentales para alcanzar este logro histórico.
        </p>
    </div>
    <img src="img/champions.jpg" alt="Trophy de la Champions">
</div>


      

  <div id="aviso-cookies" class="aviso-cookies hidden">
    <p>Este sitio web utiliza cookies para mejorar la experiencia del usuario. Al continuar utilizando este sitio,
      aceptas el uso de cookies.</p>
    <button id="aceptar-cookies">Aceptar</button>
  </div>

  <div class="filosofia-negocio">
  <h2>Filosofia a lo chapero</h2>
  <p>
    En nuestra empresa, nos comprometemos a proporcionar una experiencia de compra en línea excepcional para nuestros clientes. Nos esforzamos por ofrecer un sitio web intuitivo, seguro y fácil de usar para navegar a través de una amplia gama de productos y artículos relacionados con nuestro equipo de fútbol.
  </p>
  <p>
    Valoramos la satisfacción del cliente y nos esforzamos por brindar un servicio al cliente excepcional en cada paso del proceso de compra. Nuestro objetivo es asegurarnos de que cada cliente se sienta satisfecho con su compra, desde la selección del producto hasta la entrega y el soporte posterior a la venta.
  </p>
  <p>
    Además, nos comprometemos a garantizar la seguridad y la protección de la información del cliente durante toda la experiencia de compra. Trabajamos continuamente para mejorar nuestros servicios y procesos para cumplir con las expectativas y necesidades de nuestros clientes.
  </p>
</div>

<div class="map-container">    
    <iframe
        width="600"
        height="600"
        style="border:0"
        loading="lazy"
        allowfullscreen
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1603.624588074583!2d-4.77912534772381!3d36.499846774028!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd73208e0d9647e1%3A0x88a26e08488fd7b!2sEstadio%20Santa%20Mar%C3%ADa!5e0!3m2!1ses!2ses!4v1701365470859!5m2!1ses!2ses">
    </iframe>
</div>
  <div class="location-info">
    <p>Calle Joaquin Rodrigo 25, Málaga, España</p>
  </div>


  <script src="scripts/script2.js"></script>

<footer>
<p> C.D. Las Chapas &copy; <?php echo date("Y"); ?></p>
</footer>
</body>


</html>