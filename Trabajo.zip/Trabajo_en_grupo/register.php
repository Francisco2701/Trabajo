<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tienda de Deportes - Registro</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />
  <link rel="stylesheet" href="styles/styles32.css">

</head>

<body>
  <div class="register-box"> 
    <h1>Registrarse Aquí</h1> 

      <form action="registerconexion.php" method="POST">
      <label for="username">Nombre de usuario</label>
      <input type="text" name="username" placeholder="Ingresa tu nombre de usuario" required> 
      
      <label for="email">Correo electrónico</label>
      <input type="email" name="email" placeholder="Ingresa tu correo electrónico" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" title="Por favor, ingresa un correo electrónico válido" required>

      <label for="password">Contraseña</label>
      <input type="password" name="password" placeholder="Ingresa tu contraseña" required>

      <input type="submit" value="Registrarse"> 
      <a href="login.php">¿Ya tienes una cuenta?</a> 
    </form>
    
    <a href="principal.php">Volver a la página principal</a>
    
    <script src="scripts/register.js"></script>
  </div>
</body>

</html>
