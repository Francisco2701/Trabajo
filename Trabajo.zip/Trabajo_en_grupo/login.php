<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tienda de Deportes - Login</title>
  <link rel="stylesheet" href="styles/styles2.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    integrity="sha512-..." crossorigin="anonymous" />
</head>

<body>
  <div class="login-box">  
    <h1>Inicia sesion</h1>
    <form action="loginconexion.php" method="POST"> 
      <label for="username">Usuario</label>
      <input type="text" name="username" placeholder="Introduzca su nombre de usuario"> 
      <label for="password">Contraseña</label>
      <input type="password" name="password" placeholder="Introduzca su contraseña"> 
      <input type="submit" value="Log In">
      <a href="#">He olvidado mi contraseña</a><br>
      <a href="register.php">¿No estas registrado?</a>
    </form>
    <script src="scripts/login.js"></script>
  </div>
</body>

</html>
