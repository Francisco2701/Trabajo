document.addEventListener('DOMContentLoaded', function() {
    const toggleMenu = document.getElementById("toggleMenu");
    const mainMenu = document.getElementById("mainMenu");
    const prevButton = document.querySelector('.prev-button');
    const nextButton = document.querySelector('.next-button');
    const productGroups = document.querySelectorAll('.product-group');
    const avisoCookies = document.getElementById('aviso-cookies');
    const btnAceptarCookies = document.getElementById('aceptar-cookies');
    let currentIndex = 0;
  
    function mostrarAvisoCookies() {
      const mensaje = "Este sitio web utiliza cookies para mejorar la experiencia del usuario. Al continuar utilizando este sitio, aceptas el uso de cookies.";
      alert(mensaje);
    }
  
    if (!localStorage.getItem('cookiesAceptadas')) {
      mostrarAvisoCookies();
    }
  
    btnAceptarCookies.addEventListener('click', function () {
      avisoCookies.classList.add('hidden');
      localStorage.setItem('cookiesAceptadas', 'true');
    });
  
    toggleMenu.addEventListener("click", function () {
      if (mainMenu.classList.contains("hidden")) {
        mainMenu.classList.remove("hidden");
        mainMenu.style.left = "0";
      } else {
        mainMenu.classList.add("hidden");
        mainMenu.style.left = "-250px";
      }
    });
  
    nextButton.addEventListener('click', () => {
      const maxIndex = productGroups.length - 1;
      if (currentIndex < maxIndex) {
        currentIndex++;
        updateProductDisplay();
      }
    });
  
    prevButton.addEventListener('click', () => {
      if (currentIndex > 0) {
        currentIndex--;
        updateProductDisplay();
      }
    });
  
    function updateProductDisplay() {
      productGroups.forEach((group, index) => {
        if (index === currentIndex) {
          group.classList.remove('hidden');
        } else {
          group.classList.add('hidden');
        }
      });
    }
  });