<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ficha de Producto</title>
  <link rel="stylesheet" href="estilo.css">
</head>

<body>
<header>
    <h1 class="logo">LasChapas</h1>

    <nav id="mainMenu" class="hidden">
        <ul>
            <li><a href="#">Hombre</a></li>
            <li><a href="#">Mujer</a></li>
            <li><a href="#">Niño</a></li>
            <li><a href="#">Novedades</a></li>
        </ul>
    </nav>

    <div class="nav-items">
        <button id="toggleMenu">
            <i class="fas fa-home"></i>
        </button>

        <form class="search-form">
            <input type="text" placeholder="Buscar...">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>

        <a href="register.php" class="user-icon">
            <i class="fas fa-user"></i>
        </a>
    </div>
</header>
  <div class="product-card">
    <img src="url_de_la_imagen" alt="Imagen del Producto">
    <h1>Nombre del Producto</h1>
    <p>Descripción breve del producto.</p>
    <button>Añadir al carrito</button>
  </div>

  <footer>
<p> C.D. Las Chapas &copy; <?php echo date("Y"); ?></p>
</footer>

</body>

</html>
