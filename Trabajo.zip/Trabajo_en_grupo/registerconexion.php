<?php
$servername = "127.0.0.1";
$username = "admin";
$password = "admin1234";
$dbname = "productos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $sql = "INSERT INTO usuarios (username, password, email) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sss", $username, $password, $email);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Registro exitoso. Redirigiendo a la página principal...";
            header("Location: principal.php");
            exit();
        } else {
            echo "Error al registrar el usuario.";
        }
    } else {
        echo "Error en la consulta preparada: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "No se recibieron datos del formulario.";
}

$conn->close();
?>
